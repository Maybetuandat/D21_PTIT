/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tinhsothoigianday;

/**
 *
 * @author Dell Gaming
 */
class GiangVien {
      private String magv, tengv;

    public GiangVien(String magv, String tengv) {
        this.magv = magv;
        this.tengv = tengv;
    }

    public String getMagv() {
        return magv;
    }

    public String getTengv() {
        return tengv;
    }
      
}
