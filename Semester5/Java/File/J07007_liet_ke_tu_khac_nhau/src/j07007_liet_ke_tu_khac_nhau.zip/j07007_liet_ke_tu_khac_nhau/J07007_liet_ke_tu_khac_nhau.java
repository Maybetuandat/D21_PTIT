/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package j07007_liet_ke_tu_khac_nhau;

import java.io.IOException;

/**
 *
 * @author Dell Gaming
 */
public class J07007_liet_ke_tu_khac_nhau {

   
    public static void main(String[] args) throws IOException {
            WordSet ws = new WordSet("VANBAN.in");
           System.out.println(ws);
    }
    
}
