/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package J04001_khoi_tao_lop_point;

/**
 *
 * @author Dell Gaming
 */
public class adu {
    
}
